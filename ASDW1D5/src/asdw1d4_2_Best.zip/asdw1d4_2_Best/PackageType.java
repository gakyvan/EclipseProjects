package asdw1d4_2_Best;

public enum PackageType {
	BAG,WRAP,BOX

}
