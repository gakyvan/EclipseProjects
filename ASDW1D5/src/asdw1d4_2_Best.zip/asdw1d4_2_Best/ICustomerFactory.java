package asdw1d4_2_Best;

public interface ICustomerFactory {
	GiftItem getGiftItem(PackageType type);

}
